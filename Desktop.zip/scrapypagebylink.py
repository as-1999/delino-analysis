import requests
from bs4 import BeautifulSoup
import re
import csv
myDict = {}
##############################
f = open("cafe3.txt", "r")
link = []
for i in f:
    link.append(i.strip())
f.close()
##############################len(link)

for k in range(len(link)):
    data= []
    url = "https://fidilio.com/"
    r = requests.get(url + link[k])
    try:
        print(k)
        print(link[k])
        soup = BeautifulSoup(r.text, 'html.parser')
        data.append((soup.find("div", {"class": "venue-name-box"})).find("h1", {"property": "name"}).get_text())
        data.append((soup.find_all("div", {"class": "venue-rate-box"})[0].getText()).split())
        data.append(soup.find("span", {"property": "address"}).get_text().strip())
        data.append(soup.find("ul", {"class": "infolist"}).findChildren("a")[0].getText().strip())
        data.append(soup.find("i", {"class": "icon fa fa-lg fa-clock-o"}).nextSibling.nextSibling.getText().strip())
        data.append((soup.find("div", {"class": "map-container"})).find("a")["href"])
        data.append((soup.find("div", {"class": "map-container"})).find("a", {"class": "navigation-link"})["href"])
    except:
        pass
    myDict[link[k]] = data

print(myDict)
