import requests
from bs4 import BeautifulSoup
import  re
name = []
address = []
link = []
rate = []
phone = []
for j in range(1, 43):
    url = "https://fidilio.com/coffeeshops/in/tehran/%D8%AA%D9%87%D8%B1%D8%A7%D9%86/?p="
    page = str(j)
    r = requests.get(url+page)
    soup = BeautifulSoup(r.text, 'html.parser')
    print(url+page)
    f = open("cafe3.txt", "a")
    for i in range(24):
        find_child = soup.find_all("div", {"class": "w-full justify-center items-center bg-white rounded-3xl h-fit shadow-[0px_10px_25px_0px_rgba(0,0,0,0.3)]"})[i]
        s =find_child.findChildren("a")[0]["href"]
        x = re.search("\/.*\/", s).group(0)
        f.write(x+'\n')
