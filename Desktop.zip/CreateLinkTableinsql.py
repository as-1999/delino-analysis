from dic3 import a
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="security",
    database = "geeksforgeeks"
)
cursor = mydb.cursor()

for i in a.keys():
    try:

        sql = "INSERT INTO link3 (link, linkmap1, linkmap2) VALUES (%s, %s, %s)"
        val = (i, a[i][5], a[i][6])
        cursor.execute(sql, val)
    except:
        pass
mydb.commit()
