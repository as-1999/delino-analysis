from dic3 import a
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="security",
    database = "geeksforgeeks"
)
cursor = mydb.cursor()

for i in a.keys():
    try:
        sql = "INSERT INTO place3 (link, name, rate, price, address, phoneNumber, Duration) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        val = (i, a[i][0], a[i][1][0], a[i][1][-1], a[i][2], a[i][3], a[i][4])
        cursor.execute(sql, val)
    except:
        pass
mydb.commit()
